Integrantes del grupo: Valentin Luis Garello y Julian Bidone.
